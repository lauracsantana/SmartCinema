package javax.jmdns;

public class ServiceInfo {

	public static ServiceInfo create(String serviceType, String serviceName, int servicePort, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPort() {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] getHostAddresses() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}



}

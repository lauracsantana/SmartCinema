package javax.jmdns;

public class ServiceListener {

	public void serviceAdded(ServiceEvent event) {
		// TODO Auto-generated method stub
		
	}

	public void serviceRemoved(ServiceEvent event) {
		// TODO Auto-generated method stub
		
	}

	public void serviceResolved(ServiceEvent event) {
		// TODO Auto-generated method stub
		
	}

}

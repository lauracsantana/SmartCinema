package javax.jmdns;


public class JmDNS {

	public static JmDNS create() {
		// TODO Auto-generated method stub
		return null;
	}

	public void unregisterService(ServiceInfo serviceInfo) {
		// TODO Auto-generated method stub
		
	}

	public void registerService(ServiceInfo serviceInfo) {
		// TODO Auto-generated method stub
		
	}

	public void addServiceListener(String serviceType, ServiceListener serviceListener) {
		// TODO Auto-generated method stub
		
	}

}

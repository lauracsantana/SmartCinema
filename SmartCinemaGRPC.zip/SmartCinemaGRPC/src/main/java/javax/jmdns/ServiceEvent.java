package javax.jmdns;

public class ServiceEvent {

	public ServiceInfo getInfo() {
		// TODO Auto-generated method stub
		return null;
	}

}
